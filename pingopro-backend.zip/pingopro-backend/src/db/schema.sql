-- Create partners table
CREATE TABLE IF NOT EXISTS partners (
    id SERIAL PRIMARY KEY,
    phone VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(100),
    email VARCHAR(255),
    otp_code VARCHAR(6),
    otp_expires TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER REFERENCES partners(id),
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(10) NOT NULL,
    pickup_address TEXT NOT NULL,
    drop_address TEXT NOT NULL,
    pickup_lat FLOAT,
    pickup_lng FLOAT,
    drop_lat FLOAT,
    drop_lng FLOAT,
    status VARCHAR(20) DEFAULT 'PENDING',
    amount DECIMAL(10,2) DEFAULT 0,
    distance_km FLOAT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER REFERENCES partners(id),
    vehicle_type VARCHAR(50) NOT NULL,
    vehicle_number VARCHAR(20) UNIQUE NOT NULL,
    model VARCHAR(50),
    color VARCHAR(30),
    is_available BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create earnings table
CREATE TABLE IF NOT EXISTS earnings (
    id SERIAL PRIMARY KEY,
    partner_id INTEGER REFERENCES partners(id),
    order_id INTEGER REFERENCES orders(id),
    amount DECIMAL(10,2) NOT NULL,
    earning_type VARCHAR(20) DEFAULT 'TRIP',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_orders_partner ON orders(partner_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_earnings_partner ON earnings(partner_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_partner ON vehicles(partner_id);