// src/app.js
require('dotenv').config({ path: __dirname + '/.env' });
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const app     = express();

// Middleware
app.use(cors());
app.use(helmet());
app.use(express.json());

// Health check — visit http://localhost:3000 to confirm it is running
app.get('/', (req, res) => {
  res.json({ message: 'Pingopro API is running!', version: '1.0' });
});

// Routes
app.use('/v1/auth',     require('./routes/auth'));
app.use('/v1/partner',  require('./routes/partner'));
app.use('/v1/orders',   require('./routes/orders'));
app.use('/v1/earnings', require('./routes/earnings'));
app.use('/v1/vehicle',  require('./routes/vehicle'));

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Pingopro API running on http://localhost:${PORT}`);
});