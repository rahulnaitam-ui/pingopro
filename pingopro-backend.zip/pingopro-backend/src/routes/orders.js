// src/routes/orders.js
const express    = require('express');
const router     = express.Router();
const pool       = require('../db/pool');
const authenticate = require('../middleware/auth');

// GET /v1/orders/active — get orders being delivered right now
router.get('/active', authenticate, async (req, res) => {
  const result = await pool.query(
    `SELECT * FROM orders
     WHERE partner_id = $1
     AND status IN ('ACCEPTED','IN_TRANSIT')
     ORDER BY created_at DESC`,
    [req.partnerId]
  );
  res.json({ success: true, data: result.rows });
});

// GET /v1/orders/upcoming — scheduled orders
router.get('/upcoming', authenticate, async (req, res) => {
  const result = await pool.query(
    `SELECT * FROM orders
     WHERE partner_id = $1 AND status = 'SCHEDULED'
     ORDER BY scheduled_time ASC`,
    [req.partnerId]
  );
  res.json({ success: true, data: result.rows });
});

// POST /v1/orders/:orderId/accept
router.post('/:orderId/accept', authenticate, async (req, res) => {
  const result = await pool.query(
    `UPDATE orders
     SET status = 'ACCEPTED', partner_id = $1
     WHERE id = $2 AND status = 'NEW'
     RETURNING *`,
    [req.partnerId, req.params.orderId]
  );
  if (result.rows.length === 0) {
    return res.status(400).json({ success: false, message: 'Order not available' });
  }
  res.json({ success: true, data: result.rows[0] });
});

// POST /v1/orders/:orderId/deliver
router.post('/:orderId/deliver', authenticate, async (req, res) => {
  const result = await pool.query(
    `UPDATE orders
     SET status = 'DELIVERED', completed_at = NOW()
     WHERE id = $1 AND partner_id = $2
     RETURNING *`,
    [req.params.orderId, req.partnerId]
  );
  // Add to earnings table
  await pool.query(
    `INSERT INTO earnings (partner_id, order_id, amount)
     VALUES ($1, $2, $3)`,
    [req.partnerId, req.params.orderId, result.rows[0].actual_fare || result.rows[0].estimated_fare]
  );
  res.json({ success: true, data: result.rows[0] });
});

module.exports = router;
8