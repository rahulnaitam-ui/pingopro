// src/routes/earnings.js
const express = require('express');
const router  = express.Router();

module.exports = router;