// src/routes/auth.js
const express = require('express');
const router  = express.Router();
const pool    = require('../db/pool');
const jwt     = require('jsonwebtoken');
require('dotenv').config();

// POST /v1/auth/send-otp
router.post('/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone || phone.length !== 10) {
      return res.status(400).json({ success: false, message: 'Invalid phone number' });
    }

    // Generate a 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expires = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    // Save OTP to database (create partner if not exists)
    await pool.query(
      `INSERT INTO partners (phone, otp_code, otp_expires)
       VALUES ($1, $2, $3)
       ON CONFLICT (phone) DO UPDATE
       SET otp_code = $2, otp_expires = $3`,
      [phone, otp, expires]
    );

    // In development, print OTP to console
    // In production, send via SMS (Twilio / MSG91)
    console.log(`OTP for ${phone}: ${otp}`);

    res.json({ success: true, message: 'OTP sent successfully' });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// POST /v1/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;

    // Find partner by phone
    const result = await pool.query(
      'SELECT * FROM partners WHERE phone = $1', [phone]
    );

    const partner = result.rows[0];

    // Check OTP is correct and not expired
    if (!partner || partner.otp_code !== otp) {
      return res.status(401).json({ success: false, message: 'Wrong OTP' });
    }
    if (new Date() > new Date(partner.otp_expires)) {
      return res.status(401).json({ success: false, message: 'OTP expired. Request a new one.' });
    }

    // Create a JWT token — this is what the app stores and sends with every request
    const token = jwt.sign(
      { partnerId: partner.id, phone: partner.phone },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      success: true,
      data: {
        token,
        partnerId: partner.id,
        partner: {
          id: partner.id,
          name: partner.name || 'Partner',
          phone: partner.phone,
          rating: partner.rating,
          totalTrips: partner.total_trips,
          isOnline: partner.is_online,
          isVerified: partner.is_verified,
          wallet: { balance: partner.wallet_balance }
        }
      }
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;