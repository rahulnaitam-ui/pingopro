// src/middleware/auth.js
const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'No token provided. Please login first.'
    });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.partnerId = decoded.partnerId;
    req.phone = decoded.phone;
    next(); // allow the request to continue
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Token is invalid or expired. Please login again.'
    });
  }
};