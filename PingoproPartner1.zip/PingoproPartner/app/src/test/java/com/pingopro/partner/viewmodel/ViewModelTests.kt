package com.pingopro.partner.viewmodel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.pingopro.partner.data.model.*
import com.pingopro.partner.data.repository.PingoproRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.*
import org.junit.Assert.*
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations
import retrofit2.Response

@ExperimentalCoroutinesApi
class HomeViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private val testDispatcher = StandardTestDispatcher()

    @Mock
    lateinit var repository: PingoproRepository

    private lateinit var viewModel: HomeViewModel

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
        viewModel = HomeViewModel(repository)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `loadProfile emits Loading then Success`() = runTest {
        val fakePartner = Partner(
            id = "1", name = "Rahul Sharma", phone = "9876543210",
            email = "rahul@test.com", rating = 4.8f, totalTrips = 3,
            isOnline = true, isVerified = true, joinedDate = "Jan 2024",
            profileImageUrl = null,
            wallet = Wallet(840.0, 0.0, "2024-01-01"),
            vehicle = null
        )
        val fakeResponse = ApiResponse(success = true, data = fakePartner, message = null, errorCode = null)

        `when`(repository.getProfile("token")).thenReturn(Response.success(fakeResponse))

        viewModel.loadProfile("token")
        testDispatcher.scheduler.advanceUntilIdle()

        val state = viewModel.profile.value
        assertTrue(state is UiState.Success)
        assertEquals("Rahul Sharma", (state as UiState.Success).data.name)
    }

    @Test
    fun `toggleOnlineStatus updates isOnline LiveData`() = runTest {
        `when`(repository.updateOnlineStatus("token", true))
            .thenReturn(Response.success(ApiResponse(true, Unit, null, null)))

        viewModel.toggleOnlineStatus("token", true)
        testDispatcher.scheduler.advanceUntilIdle()

        assertEquals(true, viewModel.isOnline.value)
    }
}

@ExperimentalCoroutinesApi
class EarningsViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private val testDispatcher = StandardTestDispatcher()

    @Mock
    lateinit var repository: PingoproRepository

    private lateinit var viewModel: EarningsViewModel

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        Dispatchers.setMain(testDispatcher)
        viewModel = EarningsViewModel(repository)
    }

    @After
    fun tearDown() { Dispatchers.resetMain() }

    @Test
    fun `loadEarnings emits correct summary`() = runTest {
        val fakeSummary = EarningsSummary(
            todayEarnings = 840.0, weeklyEarnings = 4280.0, monthlyEarnings = 18650.0,
            totalTripsToday = 3, totalTripsWeek = 12, acceptanceRate = 0.92f,
            peakHourBonus = 120.0, weeklyTargetBonus = 250.0, referralCredit = 100.0,
            walletBalance = 1240.0
        )
        val fakeResponse = ApiResponse(true, fakeSummary, null, null)
        val fakeTripResponse = ApiResponse(true, emptyList<TripEarning>(), null, null)

        `when`(repository.getEarningsSummary("token")).thenReturn(Response.success(fakeResponse))
        `when`(repository.getTripEarnings("token", 1)).thenReturn(Response.success(fakeTripResponse))

        viewModel.loadEarnings("token")
        testDispatcher.scheduler.advanceUntilIdle()

        val state = viewModel.summary.value
        assertTrue(state is UiState.Success)
        assertEquals(840.0, (state as UiState.Success).data.todayEarnings, 0.0)
    }
}
