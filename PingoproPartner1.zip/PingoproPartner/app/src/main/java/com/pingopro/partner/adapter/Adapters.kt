package com.pingopro.partner.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.pingopro.partner.data.model.Order
import com.pingopro.partner.data.model.OrderStatus
import com.pingopro.partner.databinding.ItemOrderBinding

class OrdersAdapter(
    private val onDeliverClick: (Order) -> Unit,
    private val onNavigateClick: (Order) -> Unit,
    private val onCallClick: (Order) -> Unit
) : ListAdapter<Order, OrdersAdapter.OrderViewHolder>(OrderDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class OrderViewHolder(private val binding: ItemOrderBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(order: Order) {
            binding.tvOrderId.text = "#${order.orderId}"
            binding.tvPickupAddress.text = order.pickup.address
            binding.tvDropoffAddress.text = order.dropoff.address
            binding.tvDistance.text = "${order.distanceKm} km"
            binding.tvFare.text = "₹${order.estimatedFare.toInt()}"
            binding.tvVehicleType.text = order.vehicleType
            binding.tvCustomerName.text = order.customer.name

            when (order.status) {
                OrderStatus.IN_TRANSIT -> {
                    binding.tvStatus.text = "In Transit"
                    binding.tvStatus.setBackgroundResource(com.pingopro.partner.R.drawable.bg_badge_active)
                    binding.layoutActions.visibility = View.VISIBLE
                    binding.layoutCustomer.visibility = View.VISIBLE
                    binding.tvEta.text = "${order.estimatedMinutes} min left"
                }
                OrderStatus.NEW, OrderStatus.ACCEPTED -> {
                    binding.tvStatus.text = "New"
                    binding.tvStatus.setBackgroundResource(com.pingopro.partner.R.drawable.bg_badge_new)
                    binding.layoutActions.visibility = View.GONE
                    binding.layoutCustomer.visibility = View.GONE
                    binding.tvEta.text = order.scheduledTime ?: ""
                }
                OrderStatus.SCHEDULED -> {
                    binding.tvStatus.text = "Scheduled"
                    binding.tvStatus.setBackgroundResource(com.pingopro.partner.R.drawable.bg_badge_new)
                    binding.layoutActions.visibility = View.GONE
                    binding.layoutCustomer.visibility = View.GONE
                    binding.tvEta.text = order.scheduledTime ?: ""
                }
                OrderStatus.DELIVERED -> {
                    binding.tvStatus.text = "Delivered"
                    binding.tvStatus.setBackgroundResource(com.pingopro.partner.R.drawable.bg_badge_done)
                    binding.layoutActions.visibility = View.GONE
                    binding.layoutCustomer.visibility = View.GONE
                }
                OrderStatus.CANCELLED -> {
                    binding.tvStatus.text = "Cancelled"
                    binding.tvStatus.setBackgroundResource(com.pingopro.partner.R.drawable.bg_badge_done)
                    binding.layoutActions.visibility = View.GONE
                    binding.layoutCustomer.visibility = View.GONE
                }
            }

            binding.btnDeliver.setOnClickListener { onDeliverClick(order) }
            binding.btnNavigate.setOnClickListener { onNavigateClick(order) }
            binding.btnCall.setOnClickListener { onCallClick(order) }
        }
    }

    class OrderDiffCallback : DiffUtil.ItemCallback<Order>() {
        override fun areItemsTheSame(oldItem: Order, newItem: Order) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Order, newItem: Order) = oldItem == newItem
    }
}

// ─── TripEarningsAdapter ──────────────────────────────────────────────────────

class TripEarningsAdapter : ListAdapter<com.pingopro.partner.data.model.TripEarning,
        TripEarningsAdapter.TripViewHolder>(TripDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TripViewHolder {
        val binding = com.pingopro.partner.databinding.ItemTripEarningBinding.inflate(
            LayoutInflater.from(parent.context), parent, false)
        return TripViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TripViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class TripViewHolder(private val binding: com.pingopro.partner.databinding.ItemTripEarningBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(trip: com.pingopro.partner.data.model.TripEarning) {
            binding.tvOrderId.text = "#${trip.orderId}"
            binding.tvRoute.text = "${trip.pickup} → ${trip.dropoff}"
            binding.tvAmount.text = "+₹${trip.amount.toInt()}"
            binding.tvTime.text = trip.time
        }
    }

    class TripDiffCallback : DiffUtil.ItemCallback<com.pingopro.partner.data.model.TripEarning>() {
        override fun areItemsTheSame(a: com.pingopro.partner.data.model.TripEarning, b: com.pingopro.partner.data.model.TripEarning) = a.orderId == b.orderId
        override fun areContentsTheSame(a: com.pingopro.partner.data.model.TripEarning, b: com.pingopro.partner.data.model.TripEarning) = a == b
    }
}
