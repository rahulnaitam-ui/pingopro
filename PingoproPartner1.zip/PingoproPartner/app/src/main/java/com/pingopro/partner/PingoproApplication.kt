package com.pingopro.partner

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class PingoproApplication : Application() {

    companion object {
        const val CHANNEL_TRIP_REQUESTS = "pingopro_trip_requests"
        const val CHANNEL_LOCATION      = "pingopro_location"
        const val CHANNEL_GENERAL       = "pingopro_general"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            listOf(
                NotificationChannel(
                    CHANNEL_TRIP_REQUESTS,
                    "Trip Requests",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Incoming trip request alerts"
                    enableVibration(true)
                    enableLights(true)
                },
                NotificationChannel(
                    CHANNEL_LOCATION,
                    "Location Tracking",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Background location tracking for active trips"
                },
                NotificationChannel(
                    CHANNEL_GENERAL,
                    "General",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "General Pingopro Partner notifications"
                }
            ).forEach { manager.createNotificationChannel(it) }
        }
    }
}
