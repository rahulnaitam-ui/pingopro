package com.pingopro.partner.utils

object Constants {

    // API
    const val BASE_URL            = "https://api.pingopro.com/v1/"
    const val API_TIMEOUT_SEC     = 30L
    const val OTP_LENGTH          = 6
    const val PHONE_LENGTH        = 10

    // Notification IDs
    const val NOTIF_TRIP_REQUEST  = 1001
    const val NOTIF_DELIVERY_DONE = 1002
    const val NOTIF_LOCATION      = 1003

    // Pagination
    const val PAGE_SIZE           = 20

    // Location update interval (ms)
    const val LOCATION_INTERVAL   = 10_000L
    const val LOCATION_FASTEST    = 5_000L

    // Order acceptance timeout (seconds)
    const val TRIP_REQUEST_TIMEOUT = 30

    // Date formats
    const val DATE_FORMAT_DISPLAY  = "dd MMM yyyy"
    const val DATE_FORMAT_TIME     = "hh:mm a"
    const val DATE_FORMAT_API      = "yyyy-MM-dd'T'HH:mm:ss'Z'"

    // Intent extras
    const val EXTRA_ORDER_ID      = "ORDER_ID"
    const val EXTRA_NAVIGATE_TO   = "NAVIGATE_TO"

    // Nav destinations
    const val NAV_HOME      = "home"
    const val NAV_ORDERS    = "orders"
    const val NAV_EARNINGS  = "earnings"
    const val NAV_VEHICLE   = "vehicle"
    const val NAV_PROFILE   = "profile"

    // SharedPrefs keys (also in SessionManager)
    const val PREF_FCM_TOKEN      = "fcm_token"
    const val PREF_DARK_MODE      = "dark_mode"
    const val PREF_LANGUAGE       = "language"
}
