package com.pingopro.partner.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.pingopro.partner.R
import com.pingopro.partner.databinding.FragmentHomeBinding
import com.pingopro.partner.utils.SessionManager
import com.pingopro.partner.viewmodel.HomeViewModel
import com.pingopro.partner.viewmodel.UiState

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())
        setupObservers()
        setupClickListeners()
        
        // Always load demo data first to prevent ANR/Black screen while waiting for network
        loadDemoData()
        
        // Then attempt to sync with server
        viewModel.loadProfile(session.getToken())
    }

    private fun setupObservers() {
        viewModel.profile.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Loading -> {
                    // Don't show full screen progress if we already have demo data
                    // binding.progressBar.visibility = View.VISIBLE
                }
                is UiState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    val partner = state.data
                    binding.tvGreeting.text = "Hey, ${partner.name.split(" ").first()}! 👋"
                    binding.tvSubtitle.text = "Nagpur • ${partner.totalTrips} trips today"
                    binding.tvTodayEarnings.text = "₹${partner.wallet.balance.toInt()}"
                    binding.tvRating.text = partner.rating.toString()
                    binding.switchOnline.isChecked = partner.isOnline
                }
                is UiState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    // Stay on demo data
                }
            }
        }

        viewModel.isOnline.observe(viewLifecycleOwner) { isOnline ->
            binding.switchOnline.isChecked = isOnline
            binding.tvOnlineStatus.text = if (isOnline) "Online — Accepting Trips" else "Offline"
            binding.chipOnlineStatus.text = if (isOnline) "● Online — Accepting Trips" else "● Offline"
        }

        viewModel.acceptOrderState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Success -> {
                    Toast.makeText(requireContext(), "Order accepted!", Toast.LENGTH_SHORT).show()
                    binding.cardIncomingRequest.visibility = View.GONE
                    findNavController().navigate(R.id.ordersFragment)
                }
                is UiState.Error -> {
                    Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                }
                else -> {}
            }
        }
    }

    private fun setupClickListeners() {
        binding.switchOnline.setOnCheckedChangeListener { _, isChecked ->
            viewModel.toggleOnlineStatus(session.getToken(), isChecked)
        }

        binding.btnAcceptOrder.setOnClickListener {
            viewModel.acceptOrder(session.getToken(), "PPO-5892")
        }

        binding.btnDeclineOrder.setOnClickListener {
            viewModel.declineOrder(session.getToken(), "PPO-5892")
            binding.cardIncomingRequest.visibility = View.GONE
        }

        binding.btnGoOffline.setOnClickListener {
            val current = binding.switchOnline.isChecked
            viewModel.toggleOnlineStatus(session.getToken(), !current)
        }

        binding.btnLiveMap.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_map)
        }

        binding.cardNavigate.setOnClickListener {
            Toast.makeText(requireContext(), "Opening navigation...", Toast.LENGTH_SHORT).show()
        }

        binding.cardSupport.setOnClickListener {
            Toast.makeText(requireContext(), "Opening support chat...", Toast.LENGTH_SHORT).show()
        }

        binding.cardRewards.setOnClickListener {
            Toast.makeText(requireContext(), "Rewards & milestones", Toast.LENGTH_SHORT).show()
        }

        binding.cardAnalytics.setOnClickListener {
            findNavController().navigate(R.id.earningsFragment)
        }
    }

    private fun loadDemoData() {
        binding.tvGreeting.text = "Hey, Rahul! 👋"
        binding.tvSubtitle.text = "Nagpur • 3 trips today • Partner since 2024"
        binding.tvTodayEarnings.text = "₹840"
        binding.tvRating.text = "4.8"
        binding.tvTripsCount.text = "3"
        binding.tvAcceptanceRate.text = "92%"
        binding.tvOnlineStatus.text = "Online — Accepting Trips"
        binding.cardIncomingRequest.visibility = View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
