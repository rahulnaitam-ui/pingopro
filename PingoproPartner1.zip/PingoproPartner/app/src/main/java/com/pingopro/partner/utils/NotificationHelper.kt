package com.pingopro.partner.utils

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.pingopro.partner.PingoproApplication
import com.pingopro.partner.R
import com.pingopro.partner.ui.MainActivity

object NotificationHelper {

    fun showTripRequestNotification(
        context: Context,
        orderId: String,
        pickup: String,
        dropoff: String,
        fare: String
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("ORDER_ID", orderId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, PingoproApplication.CHANNEL_TRIP_REQUESTS)
            .setSmallIcon(R.drawable.ic_vehicle)
            .setContentTitle("New Trip Request! 🚛")
            .setContentText("$pickup → $dropoff • $fare")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("Pickup: $pickup\nDrop: $dropoff\nEstimated fare: $fare\n\nTap to accept")
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setVibrate(longArrayOf(0, 500, 250, 500))
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(orderId.hashCode(), notification)
    }

    fun showDeliveryConfirmationNotification(context: Context, orderId: String, amount: String) {
        val notification = NotificationCompat.Builder(context, PingoproApplication.CHANNEL_GENERAL)
            .setSmallIcon(R.drawable.ic_earnings)
            .setContentTitle("Trip Completed! ✓")
            .setContentText("Order #$orderId delivered. $amount credited to your wallet.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }

    fun cancelAll(context: Context) {
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancelAll()
    }
}
