package com.pingopro.partner.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.pingopro.partner.R
import com.pingopro.partner.ui.auth.LoginActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler(Looper.getMainLooper()).postDelayed({
            // Always go to Login screen after Splash
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }, 1500)
    }
}
