package com.pingopro.partner.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.pingopro.partner.databinding.FragmentProfileBinding
import com.pingopro.partner.ui.auth.LoginActivity
import com.pingopro.partner.utils.SessionManager
import com.pingopro.partner.viewmodel.ProfileViewModel
import com.pingopro.partner.viewmodel.UiState

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProfileViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())
        setupObservers()
        setupClickListeners()
        loadProfileData()
        viewModel.loadProfile(session.getToken())
    }

    private fun setupObservers() {
        viewModel.profile.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Success -> {
                    val p = state.data
                    binding.tvPartnerName.text = p.name
                    binding.tvPartnerSub.text = "Pingopro Partner • Since ${p.joinedDate}"
                    binding.tvRating.text = p.rating.toString()
                    binding.tvAvatarInitial.text = p.name.first().toString()
                    binding.tvVerifiedBadge.visibility = if (p.isVerified) View.VISIBLE else View.GONE
                }
                is UiState.Error -> loadProfileData()
                else -> {}
            }
        }

        viewModel.logoutState.observe(viewLifecycleOwner) { shouldLogout ->
            if (shouldLogout) performLogout()
        }
    }

    private fun setupClickListeners() {
        binding.switchOnline.setOnCheckedChangeListener { _, isChecked ->
            session.setOnlineStatus(isChecked)
            Toast.makeText(requireContext(), if (isChecked) "You are now Online" else "You are now Offline", Toast.LENGTH_SHORT).show()
        }
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(requireContext(), if (isChecked) "Notifications enabled" else "Notifications disabled", Toast.LENGTH_SHORT).show()
        }
        binding.menuKyc.setOnClickListener { Toast.makeText(requireContext(), "Opening KYC...", Toast.LENGTH_SHORT).show() }
        binding.menuBank.setOnClickListener { Toast.makeText(requireContext(), "Opening Bank Details...", Toast.LENGTH_SHORT).show() }
        binding.menuRatings.setOnClickListener { Toast.makeText(requireContext(), "Ratings & Reviews", Toast.LENGTH_SHORT).show() }
        binding.menuServiceAreas.setOnClickListener { Toast.makeText(requireContext(), "Service Areas", Toast.LENGTH_SHORT).show() }
        binding.menuReferEarn.setOnClickListener { Toast.makeText(requireContext(), "Refer & Earn — coming soon!", Toast.LENGTH_SHORT).show() }
        binding.menuMilestones.setOnClickListener { Toast.makeText(requireContext(), "Milestone Rewards", Toast.LENGTH_SHORT).show() }
        binding.menuPerformance.setOnClickListener { Toast.makeText(requireContext(), "Performance Score", Toast.LENGTH_SHORT).show() }
        binding.menuSupport.setOnClickListener { Toast.makeText(requireContext(), "Opening Help & Support...", Toast.LENGTH_SHORT).show() }
        binding.menuComplaint.setOnClickListener { Toast.makeText(requireContext(), "Raise a Complaint", Toast.LENGTH_SHORT).show() }
        binding.menuPrivacy.setOnClickListener { Toast.makeText(requireContext(), "Privacy Policy", Toast.LENGTH_SHORT).show() }
        binding.btnLogout.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Log Out")
                .setMessage("Are you sure you want to log out from Pingopro Partner?")
                .setPositiveButton("Log Out") { _, _ -> viewModel.logout() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun loadProfileData() {
        binding.tvPartnerName.text = session.getPartnerName().ifEmpty { "Rahul Sharma" }
        binding.tvPartnerSub.text = "Pingopro Partner • Since Jan 2024"
        binding.tvRating.text = "4.8"
        binding.tvAvatarInitial.text = (session.getPartnerName().ifEmpty { "R" }).first().toString()
        binding.switchOnline.isChecked = session.isOnline()
    }

    private fun performLogout() {
        session.clearSession()
        startActivity(Intent(requireContext(), LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
