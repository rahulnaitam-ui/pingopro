package com.pingopro.partner.ui.orders

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.pingopro.partner.adapter.OrdersAdapter
import com.pingopro.partner.databinding.FragmentOrdersBinding
import com.pingopro.partner.utils.SessionManager
import com.pingopro.partner.viewmodel.OrdersViewModel
import com.pingopro.partner.viewmodel.UiState

class OrdersFragment : Fragment() {

    private var _binding: FragmentOrdersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: OrdersViewModel by viewModels()
    private lateinit var session: SessionManager
    private lateinit var ordersAdapter: OrdersAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentOrdersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())
        setupRecyclerView()
        setupTabs()
        setupObservers()
        loadOrders()
    }

    private fun setupRecyclerView() {
        ordersAdapter = OrdersAdapter(
            onDeliverClick = { order ->
                viewModel.markDelivered(session.getToken(), order.id)
            },
            onNavigateClick = { order ->
                Toast.makeText(requireContext(), "Navigating to ${order.dropoff.address}", Toast.LENGTH_SHORT).show()
            },
            onCallClick = { order ->
                Toast.makeText(requireContext(), "Calling ${order.customer.name}", Toast.LENGTH_SHORT).show()
            }
        )
        binding.rvOrders.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = ordersAdapter
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> viewModel.loadActiveOrders(session.getToken())
                    1 -> viewModel.loadUpcomingOrders(session.getToken())
                    2 -> viewModel.loadOrderHistory(session.getToken())
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupObservers() {
        viewModel.activeOrders.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Loading -> binding.progressBar.visibility = View.VISIBLE
                is UiState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    ordersAdapter.submitList(state.data)
                    binding.tvEmptyState.visibility = if (state.data.isEmpty()) View.VISIBLE else View.GONE
                }
                is UiState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvEmptyState.visibility = View.VISIBLE
                    binding.tvEmptyState.text = "No active orders right now"
                }
            }
        }

        viewModel.upcomingOrders.observe(viewLifecycleOwner) { state ->
            if (state is UiState.Success) ordersAdapter.submitList(state.data)
        }

        viewModel.orderHistory.observe(viewLifecycleOwner) { state ->
            if (state is UiState.Success) ordersAdapter.submitList(state.data)
        }

        viewModel.deliverState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Success -> Toast.makeText(requireContext(), "Order delivered! 🎉", Toast.LENGTH_SHORT).show()
                is UiState.Error -> Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                else -> {}
            }
        }
    }

    private fun loadOrders() {
        viewModel.loadActiveOrders(session.getToken())
        viewModel.loadUpcomingOrders(session.getToken())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
