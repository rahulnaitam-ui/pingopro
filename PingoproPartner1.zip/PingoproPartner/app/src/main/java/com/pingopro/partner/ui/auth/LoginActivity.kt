package com.pingopro.partner.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pingopro.partner.databinding.ActivityLoginBinding
import com.pingopro.partner.ui.MainActivity
import com.pingopro.partner.utils.SessionManager

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var session: SessionManager
    private var isOtpSent = false
    private var phoneNumber = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        session = SessionManager(this)
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnSendOtp.setOnClickListener {
            if (!isOtpSent) {
                val phone = binding.etPhone.text.toString().trim()
                if (phone.length == 10) {
                    sendOtp(phone)
                } else {
                    binding.etPhone.error = "Enter valid 10-digit number"
                }
            } else {
                val otp = binding.etOtp.text.toString().trim()
                if (otp.length == 6) {
                    verifyOtp(otp)
                } else {
                    binding.etOtp.error = "Enter valid 6-digit OTP"
                }
            }
        }

        binding.tvResendOtp.setOnClickListener {
            sendOtp(phoneNumber)
        }

        binding.btnGoToDashboard.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun sendOtp(phone: String) {
        phoneNumber = phone
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSendOtp.isEnabled = false
        // In real app: call ViewModel to send OTP via API
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            binding.progressBar.visibility = View.GONE
            binding.btnSendOtp.isEnabled = true
            isOtpSent = true
            binding.otpLayout.visibility = View.VISIBLE
            binding.tvResendOtp.visibility = View.VISIBLE
            binding.btnSendOtp.text = "Verify OTP"
            Toast.makeText(this, "OTP sent to +91$phone", Toast.LENGTH_SHORT).show()
        }, 1500)
    }

    private fun verifyOtp(otp: String) {
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSendOtp.isEnabled = false
        // Simulate OTP verification — replace with real API call
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            binding.progressBar.visibility = View.GONE
            // Save demo session
            session.saveSession(
                token = "demo_token_pingopro",
                partnerId = "PPP-001",
                name = "Rahul Sharma",
                phone = phoneNumber
            )
            
            // Show Success View instead of immediate navigation
            showRegistrationSuccess()
        }, 1500)
    }

    private fun showRegistrationSuccess() {
        binding.loginForm.visibility = View.GONE
        binding.layoutSuccess.visibility = View.VISIBLE
    }
}
