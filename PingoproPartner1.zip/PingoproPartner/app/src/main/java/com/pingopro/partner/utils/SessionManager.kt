package com.pingopro.partner.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "PingoproSession"
        const val KEY_TOKEN = "auth_token"
        const val KEY_PARTNER_ID = "partner_id"
        const val KEY_PARTNER_NAME = "partner_name"
        const val KEY_PARTNER_PHONE = "partner_phone"
        const val KEY_IS_ONLINE = "is_online"
        const val KEY_IS_LOGGED_IN = "is_logged_in"
    }

    fun saveSession(token: String, partnerId: String, name: String, phone: String) {
        prefs.edit().apply {
            putString(KEY_TOKEN, token)
            putString(KEY_PARTNER_ID, partnerId)
            putString(KEY_PARTNER_NAME, name)
            putString(KEY_PARTNER_PHONE, phone)
            putBoolean(KEY_IS_LOGGED_IN, true)
        }.apply()
    }

    fun getToken(): String = prefs.getString(KEY_TOKEN, "") ?: ""
    fun getPartnerId(): String = prefs.getString(KEY_PARTNER_ID, "") ?: ""
    fun getPartnerName(): String = prefs.getString(KEY_PARTNER_NAME, "") ?: ""
    fun getPartnerPhone(): String = prefs.getString(KEY_PARTNER_PHONE, "") ?: ""
    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    fun isOnline(): Boolean = prefs.getBoolean(KEY_IS_ONLINE, false)

    fun setOnlineStatus(isOnline: Boolean) {
        prefs.edit().putBoolean(KEY_IS_ONLINE, isOnline).apply()
    }

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
