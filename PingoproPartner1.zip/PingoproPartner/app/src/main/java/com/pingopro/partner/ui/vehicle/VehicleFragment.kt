package com.pingopro.partner.ui.vehicle

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.pingopro.partner.databinding.FragmentVehicleBinding
import com.pingopro.partner.utils.SessionManager
import com.pingopro.partner.viewmodel.UiState
import com.pingopro.partner.viewmodel.VehicleViewModel

class VehicleFragment : Fragment() {

    private var _binding: FragmentVehicleBinding? = null
    private val binding get() = _binding!!
    private val viewModel: VehicleViewModel by viewModels()
    private lateinit var session: SessionManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentVehicleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())
        setupObservers()
        setupClickListeners()
        viewModel.loadVehicle(session.getToken())
    }

    private fun setupObservers() {
        viewModel.vehicle.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Loading -> binding.progressBar.visibility = View.VISIBLE
                is UiState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    val v = state.data
                    binding.tvVehicleName.text = "${v.make} ${v.model}"
                    binding.tvVehiclePlate.text = "${v.registrationNumber} • ${v.capacityKg} kg"
                    binding.tvVehicleType.text = v.type
                    binding.tvMake.text = v.make
                    binding.tvModel.text = v.model
                    binding.tvYear.text = v.year.toString()
                    binding.tvCapacity.text = "${v.capacityKg} kg"
                    binding.tvRegNo.text = v.registrationNumber
                    // Documents
                    binding.tvRcStatus.text = if (v.documents.rc.isValid) "Valid" else "Expired"
                    binding.tvInsuranceStatus.text = "Valid • ${v.documents.insurance.expiryDate}"
                    binding.tvPermitStatus.text = if (v.documents.permit.isValid) "Valid • ${v.documents.permit.expiryDate}" else "Expired"
                }
                is UiState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    loadDemoData()
                }
            }
        }
    }

    private fun setupClickListeners() {
        binding.btnUpdateDocuments.setOnClickListener {
            Toast.makeText(requireContext(), "Opening document upload...", Toast.LENGTH_SHORT).show()
        }
        binding.btnAddVehicle.setOnClickListener {
            Toast.makeText(requireContext(), "Add new vehicle", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadDemoData() {
        binding.tvVehicleName.text = "Tata Ace Mini Truck"
        binding.tvVehiclePlate.text = "MH-31 AB 1234 • 750 kg"
        binding.tvVehicleType.text = "Mini Truck"
        binding.tvMake.text = "Tata Ace"
        binding.tvModel.text = "Ace"
        binding.tvYear.text = "2022"
        binding.tvCapacity.text = "750 kg"
        binding.tvRegNo.text = "MH31AB1234"
        binding.tvRcStatus.text = "Valid"
        binding.tvInsuranceStatus.text = "Valid • Jun 2026"
        binding.tvPermitStatus.text = "Expires in 12 days"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
