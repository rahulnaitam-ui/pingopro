package com.pingopro.partner.data.repository

import com.pingopro.partner.data.model.*
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkClient {
    private const val BASE_URL = "https://api.pingopro.com/v1/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiService: PingoproApiService = retrofit.create(PingoproApiService::class.java)
}

// ─── Repository ───────────────────────────────────────────────────────────────

class PingoproRepository(private val api: PingoproApiService = NetworkClient.apiService) {

    // Auth
    suspend fun sendOtp(phone: String) = api.sendOtp(mapOf("phone" to phone))
    suspend fun verifyOtp(phone: String, otp: String) = api.verifyOtp(LoginRequest(phone, otp))

    // Partner
    suspend fun getProfile(token: String) = api.getProfile("Bearer $token")
    suspend fun updateOnlineStatus(token: String, isOnline: Boolean) =
        api.updateOnlineStatus("Bearer $token", mapOf("isOnline" to isOnline))

    // Orders
    suspend fun getActiveOrders(token: String) = api.getActiveOrders("Bearer $token")
    suspend fun getUpcomingOrders(token: String) = api.getUpcomingOrders("Bearer $token")
    suspend fun getOrderHistory(token: String, page: Int = 1) =
        api.getOrderHistory("Bearer $token", page)
    suspend fun acceptOrder(token: String, orderId: String) =
        api.acceptOrder("Bearer $token", orderId)
    suspend fun declineOrder(token: String, orderId: String) =
        api.declineOrder("Bearer $token", orderId)
    suspend fun markDelivered(token: String, orderId: String) =
        api.markDelivered("Bearer $token", orderId)

    // Earnings
    suspend fun getEarningsSummary(token: String) = api.getEarningsSummary("Bearer $token")
    suspend fun getDailyEarnings(token: String, week: String) =
        api.getDailyEarnings("Bearer $token", week)
    suspend fun getTripEarnings(token: String, page: Int = 1) =
        api.getTripEarnings("Bearer $token", page)
    suspend fun requestPayout(token: String) = api.requestPayout("Bearer $token")

    // Vehicle
    suspend fun getVehicle(token: String) = api.getVehicle("Bearer $token")
    suspend fun updateVehicle(token: String, data: Map<String, Any>) =
        api.updateVehicle("Bearer $token", data)
}
