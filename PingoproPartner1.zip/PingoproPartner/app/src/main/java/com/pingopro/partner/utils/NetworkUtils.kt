package com.pingopro.partner.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object NetworkUtils {

    fun isConnected(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(network) ?: return false
        return cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun parseError(code: Int): String = when (code) {
        400 -> "Bad request. Please check your input."
        401 -> "Session expired. Please log in again."
        403 -> "You don't have permission for this action."
        404 -> "Resource not found."
        429 -> "Too many requests. Please slow down."
        500 -> "Server error. Please try again later."
        503 -> "Service unavailable. Please try again later."
        else -> "Something went wrong (Error $code)."
    }
}
