package com.pingopro.partner.ui.home

import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.pingopro.partner.data.model.TripRequest
import com.pingopro.partner.databinding.BottomSheetTripRequestBinding
import com.pingopro.partner.utils.Constants

class TripRequestBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetTripRequestBinding? = null
    private val binding get() = _binding!!

    private var tripRequest: TripRequest? = null
    private var onAccept: ((String) -> Unit)? = null
    private var onDecline: ((String) -> Unit)? = null
    private var countDownTimer: CountDownTimer? = null

    companion object {
        const val TAG = "TripRequestBottomSheet"

        fun newInstance(
            request: TripRequest,
            onAccept: (String) -> Unit,
            onDecline: (String) -> Unit
        ) = TripRequestBottomSheet().apply {
            this.tripRequest = request
            this.onAccept = onAccept
            this.onDecline = onDecline
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetTripRequestBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tripRequest?.let { req ->
            bindTripData(req)
            startCountdown(req.timeoutSeconds)
        }

        binding.btnAccept.setOnClickListener {
            countDownTimer?.cancel()
            tripRequest?.let { onAccept?.invoke(it.orderId) }
            dismiss()
        }

        binding.btnDecline.setOnClickListener {
            countDownTimer?.cancel()
            tripRequest?.let { onDecline?.invoke(it.orderId) }
            dismiss()
        }
    }

    private fun bindTripData(req: TripRequest) {
        with(binding) {
            tvOrderId.text = "#${req.order.orderId}"
            tvPickup.text = req.order.pickup.address
            tvDropoff.text = req.order.dropoff.address
            tvFare.text = "₹${req.order.estimatedFare.toInt()}"
            tvDistance.text = "${req.order.distanceKm} km"
            tvVehicleType.text = req.order.vehicleType
            tvEta.text = "${req.order.estimatedMinutes} min"
        }
    }

    private fun startCountdown(seconds: Int) {
        countDownTimer = object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val s = (millisUntilFinished / 1000).toInt()
                binding.tvCountdown.text = "${s}s"
                binding.progressCountdown.progress = (s * 100) / seconds
            }

            override fun onFinish() {
                tripRequest?.let { onDecline?.invoke(it.orderId) }
                dismiss()
            }
        }.start()
    }

    override fun onDestroyView() {
        countDownTimer?.cancel()
        super.onDestroyView()
        _binding = null
    }
}
