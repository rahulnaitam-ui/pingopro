package com.pingopro.partner.ui.earnings

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.pingopro.partner.adapter.TripEarningsAdapter
import com.pingopro.partner.databinding.FragmentEarningsBinding
import com.pingopro.partner.utils.SessionManager
import com.pingopro.partner.viewmodel.EarningsViewModel
import com.pingopro.partner.viewmodel.UiState

class EarningsFragment : Fragment() {

    private var _binding: FragmentEarningsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EarningsViewModel by viewModels()
    private lateinit var session: SessionManager
    private lateinit var tripAdapter: TripEarningsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentEarningsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())
        setupRecyclerView()
        setupChart()
        setupPeriodToggle()
        setupObservers()
        viewModel.loadEarnings(session.getToken())
    }

    private fun setupRecyclerView() {
        tripAdapter = TripEarningsAdapter()
        binding.rvTripEarnings.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = tripAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun setupChart() {
        val barChart: BarChart = binding.barChart
        val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val values = listOf(680f, 1050f, 840f, 1260f, 940f, 1450f, 840f)

        val entries = values.mapIndexed { i, v -> BarEntry(i.toFloat(), v) }
        val dataSet = BarDataSet(entries, "Daily Earnings").apply {
            colors = values.mapIndexed { i, _ ->
                if (i == 6) Color.parseColor("#4ECDC4") else Color.parseColor("#C8F5F2")
            }
            setDrawValues(false)
        }

        barChart.apply {
            data = BarData(dataSet).apply { barWidth = 0.6f }
            xAxis.apply {
                valueFormatter = IndexAxisValueFormatter(days)
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
                textColor = Color.parseColor("#999999")
                textSize = 10f
            }
            axisLeft.apply { setDrawGridLines(false); textColor = Color.parseColor("#999999") }
            axisRight.isEnabled = false
            legend.isEnabled = false
            description.isEnabled = false
            setTouchEnabled(false)
            animateY(800)
            invalidate()
        }
    }

    private fun setupPeriodToggle() {
        binding.toggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            viewModel.loadEarnings(session.getToken())
        }

        binding.btnRequestPayout.setOnClickListener {
            viewModel.requestPayout(session.getToken())
        }
    }

    private fun setupObservers() {
        viewModel.summary.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Loading -> binding.progressBar.visibility = View.VISIBLE
                is UiState.Success -> {
                    binding.progressBar.visibility = View.GONE
                    val s = state.data
                    binding.tvTodayEarnings.text = "₹${s.todayEarnings.toInt()}"
                    binding.tvWeeklyEarnings.text = "₹${s.weeklyEarnings.toInt()}"
                    binding.tvMonthlyEarnings.text = "₹${s.monthlyEarnings.toInt()}"
                    binding.tvWalletBalance.text = "₹${s.walletBalance.toInt()}"
                    binding.tvPeakBonus.text = "+₹${s.peakHourBonus.toInt()}"
                    binding.tvWeeklyBonus.text = "+₹${s.weeklyTargetBonus.toInt()}"
                    binding.tvReferralCredit.text = "+₹${s.referralCredit.toInt()}"
                }
                is UiState.Error -> {
                    binding.progressBar.visibility = View.GONE
                    // Load demo data
                    binding.tvTodayEarnings.text = "₹840"
                    binding.tvWeeklyEarnings.text = "₹4,280"
                    binding.tvMonthlyEarnings.text = "₹18,650"
                    binding.tvWalletBalance.text = "₹1,240"
                    binding.tvPeakBonus.text = "+₹120"
                    binding.tvWeeklyBonus.text = "+₹250"
                    binding.tvReferralCredit.text = "+₹100"
                }
            }
        }

        viewModel.tripEarnings.observe(viewLifecycleOwner) { state ->
            if (state is UiState.Success) tripAdapter.submitList(state.data)
        }

        viewModel.payoutState.observe(viewLifecycleOwner) { state ->
            when (state) {
                is UiState.Success -> Toast.makeText(requireContext(), "Payout requested! ✓", Toast.LENGTH_SHORT).show()
                is UiState.Error -> Toast.makeText(requireContext(), state.message, Toast.LENGTH_SHORT).show()
                else -> {}
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
