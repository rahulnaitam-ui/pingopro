package com.pingopro.partner.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.pingopro.partner.data.repository.PingoproRepository

/**
 * Generic ViewModel factory that injects PingoproRepository.
 * Usage: ViewModelProvider(this, ViewModelFactory(repo)).get(HomeViewModel::class.java)
 */
class ViewModelFactory(
    private val repository: PingoproRepository = PingoproRepository()
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java)     -> HomeViewModel(repository) as T
            modelClass.isAssignableFrom(OrdersViewModel::class.java)   -> OrdersViewModel(repository) as T
            modelClass.isAssignableFrom(EarningsViewModel::class.java) -> EarningsViewModel(repository) as T
            modelClass.isAssignableFrom(VehicleViewModel::class.java)  -> VehicleViewModel(repository) as T
            modelClass.isAssignableFrom(ProfileViewModel::class.java)  -> ProfileViewModel(repository) as T
            else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        }
    }
}
