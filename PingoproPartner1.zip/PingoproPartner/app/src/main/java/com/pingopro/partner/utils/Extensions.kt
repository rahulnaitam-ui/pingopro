package com.pingopro.partner.utils

import android.content.Context
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

// ─── View Extensions ─────────────────────────────────────────────────────────

fun View.show() { visibility = View.VISIBLE }
fun View.hide() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }

fun View.showIf(condition: Boolean) {
    visibility = if (condition) View.VISIBLE else View.GONE
}

// ─── Context / Fragment Extensions ───────────────────────────────────────────

fun Context.toast(msg: String, long: Boolean = false) {
    Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()
}

fun Fragment.toast(msg: String, long: Boolean = false) {
    requireContext().toast(msg, long)
}

// ─── Number / Currency ───────────────────────────────────────────────────────

fun Double.toRupees(): String {
    val fmt = NumberFormat.getNumberInstance(Locale("en", "IN"))
    return "₹${fmt.format(this.toLong())}"
}

fun Int.toRupees(): String = this.toDouble().toRupees()

fun Double.toRupeesWithSign(): String = "+${toRupees()}"

fun Float.toStarRating(): String = String.format("%.1f ★", this)

// ─── Date / Time ─────────────────────────────────────────────────────────────

fun String.toDisplayDate(): String = try {
    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault())
    val date = sdf.parse(this)
    val out  = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    out.format(date ?: Date())
} catch (e: Exception) { this }

fun String.toDisplayTime(): String = try {
    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault())
    val date = sdf.parse(this)
    val out  = SimpleDateFormat("hh:mm a", Locale.getDefault())
    out.format(date ?: Date())
} catch (e: Exception) { this }

// ─── String Helpers ──────────────────────────────────────────────────────────

fun String.initials(): String {
    val parts = trim().split(" ")
    return when {
        parts.size >= 2 -> "${parts[0][0]}${parts[1][0]}".uppercase()
        parts.isNotEmpty() -> parts[0][0].toString().uppercase()
        else -> "?"
    }
}

fun String.firstWord(): String = trim().split(" ").firstOrNull() ?: this
