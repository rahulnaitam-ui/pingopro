package com.pingopro.partner.utils

import android.view.View
import android.widget.TextView
import androidx.databinding.BindingAdapter
import com.pingopro.partner.data.model.OrderStatus

object BindingAdapters {

    @JvmStatic
    @BindingAdapter("visibleIf")
    fun setVisibleIf(view: View, condition: Boolean) {
        view.visibility = if (condition) View.VISIBLE else View.GONE
    }

    @JvmStatic
    @BindingAdapter("rupeesAmount")
    fun setRupeesAmount(textView: TextView, amount: Double) {
        textView.text = amount.toRupees()
    }

    @JvmStatic
    @BindingAdapter("rupeesAmountInt")
    fun setRupeesAmountInt(textView: TextView, amount: Int) {
        textView.text = amount.toRupees()
    }

    @JvmStatic
    @BindingAdapter("orderStatusText")
    fun setOrderStatusText(textView: TextView, status: OrderStatus?) {
        textView.text = when (status) {
            OrderStatus.NEW       -> "New"
            OrderStatus.ACCEPTED  -> "Accepted"
            OrderStatus.IN_TRANSIT -> "In Transit"
            OrderStatus.DELIVERED -> "Delivered"
            OrderStatus.CANCELLED -> "Cancelled"
            OrderStatus.SCHEDULED -> "Scheduled"
            null                  -> ""
        }
    }

    @JvmStatic
    @BindingAdapter("starRating")
    fun setStarRating(textView: TextView, rating: Float) {
        textView.text = rating.toStarRating()
    }

    @JvmStatic
    @BindingAdapter("displayDate")
    fun setDisplayDate(textView: TextView, date: String?) {
        textView.text = date?.toDisplayDate() ?: ""
    }

    @JvmStatic
    @BindingAdapter("displayTime")
    fun setDisplayTime(textView: TextView, time: String?) {
        textView.text = time?.toDisplayTime() ?: ""
    }
}
