package com.pingopro.partner.data.repository

import com.pingopro.partner.data.model.*
import retrofit2.Response
import retrofit2.http.*

interface PingoproApiService {

    // ─── Auth ──────────────────────────────────────────────────────────────
    @POST("auth/send-otp")
    suspend fun sendOtp(@Body body: Map<String, String>): Response<ApiResponse<String>>

    @POST("auth/verify-otp")
    suspend fun verifyOtp(@Body request: LoginRequest): Response<ApiResponse<LoginResponse>>

    @POST("auth/logout")
    suspend fun logout(@Header("Authorization") token: String): Response<ApiResponse<Unit>>

    // ─── Partner ───────────────────────────────────────────────────────────
    @GET("partner/profile")
    suspend fun getProfile(@Header("Authorization") token: String): Response<ApiResponse<Partner>>

    @PUT("partner/status")
    suspend fun updateOnlineStatus(
        @Header("Authorization") token: String,
        @Body body: Map<String, Boolean>
    ): Response<ApiResponse<Unit>>

    @PUT("partner/profile")
    suspend fun updateProfile(
        @Header("Authorization") token: String,
        @Body partner: Map<String, Any>
    ): Response<ApiResponse<Partner>>

    // ─── Orders ────────────────────────────────────────────────────────────
    @GET("orders/active")
    suspend fun getActiveOrders(@Header("Authorization") token: String): Response<ApiResponse<List<Order>>>

    @GET("orders/upcoming")
    suspend fun getUpcomingOrders(@Header("Authorization") token: String): Response<ApiResponse<List<Order>>>

    @GET("orders/history")
    suspend fun getOrderHistory(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 20
    ): Response<ApiResponse<List<Order>>>

    @POST("orders/{orderId}/accept")
    suspend fun acceptOrder(
        @Header("Authorization") token: String,
        @Path("orderId") orderId: String
    ): Response<ApiResponse<Order>>

    @POST("orders/{orderId}/decline")
    suspend fun declineOrder(
        @Header("Authorization") token: String,
        @Path("orderId") orderId: String
    ): Response<ApiResponse<Unit>>

    @POST("orders/{orderId}/deliver")
    suspend fun markDelivered(
        @Header("Authorization") token: String,
        @Path("orderId") orderId: String
    ): Response<ApiResponse<Order>>

    // ─── Earnings ──────────────────────────────────────────────────────────
    @GET("earnings/summary")
    suspend fun getEarningsSummary(@Header("Authorization") token: String): Response<ApiResponse<EarningsSummary>>

    @GET("earnings/daily")
    suspend fun getDailyEarnings(
        @Header("Authorization") token: String,
        @Query("week") week: String
    ): Response<ApiResponse<List<DailyEarning>>>

    @GET("earnings/trips")
    suspend fun getTripEarnings(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1
    ): Response<ApiResponse<List<TripEarning>>>

    @POST("earnings/payout")
    suspend fun requestPayout(@Header("Authorization") token: String): Response<ApiResponse<Unit>>

    // ─── Vehicle ───────────────────────────────────────────────────────────
    @GET("vehicle")
    suspend fun getVehicle(@Header("Authorization") token: String): Response<ApiResponse<Vehicle>>

    @PUT("vehicle")
    suspend fun updateVehicle(
        @Header("Authorization") token: String,
        @Body vehicle: Map<String, Any>
    ): Response<ApiResponse<Vehicle>>

    @POST("vehicle/documents/upload")
    suspend fun uploadDocument(
        @Header("Authorization") token: String,
        @Body body: Map<String, String>
    ): Response<ApiResponse<Document>>
}
