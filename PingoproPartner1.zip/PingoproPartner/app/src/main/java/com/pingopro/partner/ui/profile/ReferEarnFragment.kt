package com.pingopro.partner.ui.profile

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.fragment.app.Fragment
import com.pingopro.partner.databinding.FragmentReferEarnBinding
import com.pingopro.partner.utils.SessionManager
import com.pingopro.partner.utils.toast

class ReferEarnFragment : Fragment() {

    private var _binding: FragmentReferEarnBinding? = null
    private val binding get() = _binding!!
    private lateinit var session: SessionManager

    // Demo referral code
    private val referralCode = "PINGO2024"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReferEarnBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        session = SessionManager(requireContext())

        binding.tvReferralCode.text = referralCode
        binding.tvReferralEarnings.text = "₹100 per successful referral"

        binding.btnCopyCode.setOnClickListener {
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Referral Code", referralCode))
            toast("Referral code copied!")
        }

        binding.btnShareCode.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(
                    Intent.EXTRA_TEXT,
                    "Join me on Pingopro Partner and start earning! Use my referral code: $referralCode\n\nDownload the app: https://pingopro.com/partner"
                )
            }
            startActivity(Intent.createChooser(shareIntent, "Share via"))
        }

        binding.btnBack.setOnClickListener {
            requireActivity().onBackPressed()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
