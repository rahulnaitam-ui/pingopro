package com.pingopro.partner.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pingopro.partner.data.model.*
import com.pingopro.partner.data.repository.PingoproRepository
import kotlinx.coroutines.launch

sealed class UiState<out T> {
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

// ─── HomeViewModel ────────────────────────────────────────────────────────────

class HomeViewModel(private val repo: PingoproRepository = PingoproRepository()) : ViewModel() {

    private val _profile = MutableLiveData<UiState<Partner>>()
    val profile: LiveData<UiState<Partner>> = _profile

    private val _isOnline = MutableLiveData<Boolean>()
    val isOnline: LiveData<Boolean> = _isOnline

    private val _incomingRequest = MutableLiveData<TripRequest?>()
    val incomingRequest: LiveData<TripRequest?> = _incomingRequest

    private val _acceptOrderState = MutableLiveData<UiState<Order>>()
    val acceptOrderState: LiveData<UiState<Order>> = _acceptOrderState

    fun loadProfile(token: String) {
        _profile.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.getProfile(token)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _profile.value = UiState.Success(resp.body()!!.data!!)
                    _isOnline.value = resp.body()!!.data!!.isOnline
                } else {
                    _profile.value = UiState.Error(resp.body()?.message ?: "Failed to load profile")
                }
            } catch (e: Exception) {
                _profile.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun toggleOnlineStatus(token: String, isOnline: Boolean) {
        viewModelScope.launch {
            try {
                val resp = repo.updateOnlineStatus(token, isOnline)
                if (resp.isSuccessful) {
                    _isOnline.value = isOnline
                }
            } catch (e: Exception) {
                // revert on failure
                _isOnline.value = !isOnline
            }
        }
    }

    fun acceptOrder(token: String, orderId: String) {
        _acceptOrderState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.acceptOrder(token, orderId)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _acceptOrderState.value = UiState.Success(resp.body()!!.data!!)
                    _incomingRequest.value = null
                } else {
                    _acceptOrderState.value = UiState.Error("Failed to accept order")
                }
            } catch (e: Exception) {
                _acceptOrderState.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun declineOrder(token: String, orderId: String) {
        viewModelScope.launch {
            try {
                repo.declineOrder(token, orderId)
                _incomingRequest.value = null
            } catch (e: Exception) {
                _incomingRequest.value = null
            }
        }
    }

    fun setIncomingRequest(request: TripRequest?) {
        _incomingRequest.value = request
    }
}

// ─── OrdersViewModel ──────────────────────────────────────────────────────────

class OrdersViewModel(private val repo: PingoproRepository = PingoproRepository()) : ViewModel() {

    private val _activeOrders = MutableLiveData<UiState<List<Order>>>()
    val activeOrders: LiveData<UiState<List<Order>>> = _activeOrders

    private val _upcomingOrders = MutableLiveData<UiState<List<Order>>>()
    val upcomingOrders: LiveData<UiState<List<Order>>> = _upcomingOrders

    private val _orderHistory = MutableLiveData<UiState<List<Order>>>()
    val orderHistory: LiveData<UiState<List<Order>>> = _orderHistory

    private val _deliverState = MutableLiveData<UiState<Order>>()
    val deliverState: LiveData<UiState<Order>> = _deliverState

    fun loadActiveOrders(token: String) {
        _activeOrders.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.getActiveOrders(token)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _activeOrders.value = UiState.Success(resp.body()!!.data ?: emptyList())
                } else {
                    _activeOrders.value = UiState.Error("Failed to load active orders")
                }
            } catch (e: Exception) {
                _activeOrders.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun loadUpcomingOrders(token: String) {
        viewModelScope.launch {
            try {
                val resp = repo.getUpcomingOrders(token)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _upcomingOrders.value = UiState.Success(resp.body()!!.data ?: emptyList())
                }
            } catch (e: Exception) {
                _upcomingOrders.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun loadOrderHistory(token: String, page: Int = 1) {
        viewModelScope.launch {
            try {
                val resp = repo.getOrderHistory(token, page)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _orderHistory.value = UiState.Success(resp.body()!!.data ?: emptyList())
                }
            } catch (e: Exception) {
                _orderHistory.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun markDelivered(token: String, orderId: String) {
        _deliverState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.markDelivered(token, orderId)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _deliverState.value = UiState.Success(resp.body()!!.data!!)
                    loadActiveOrders(token)
                } else {
                    _deliverState.value = UiState.Error("Failed to mark delivered")
                }
            } catch (e: Exception) {
                _deliverState.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }
}

// ─── EarningsViewModel ────────────────────────────────────────────────────────

class EarningsViewModel(private val repo: PingoproRepository = PingoproRepository()) : ViewModel() {

    private val _summary = MutableLiveData<UiState<EarningsSummary>>()
    val summary: LiveData<UiState<EarningsSummary>> = _summary

    private val _dailyEarnings = MutableLiveData<UiState<List<DailyEarning>>>()
    val dailyEarnings: LiveData<UiState<List<DailyEarning>>> = _dailyEarnings

    private val _tripEarnings = MutableLiveData<UiState<List<TripEarning>>>()
    val tripEarnings: LiveData<UiState<List<TripEarning>>> = _tripEarnings

    private val _payoutState = MutableLiveData<UiState<Unit>>()
    val payoutState: LiveData<UiState<Unit>> = _payoutState

    fun loadEarnings(token: String) {
        _summary.value = UiState.Loading
        viewModelScope.launch {
            try {
                val summaryResp = repo.getEarningsSummary(token)
                if (summaryResp.isSuccessful && summaryResp.body()?.success == true) {
                    _summary.value = UiState.Success(summaryResp.body()!!.data!!)
                } else {
                    _summary.value = UiState.Error("Failed to load earnings")
                }
                val tripsResp = repo.getTripEarnings(token)
                if (tripsResp.isSuccessful && tripsResp.body()?.success == true) {
                    _tripEarnings.value = UiState.Success(tripsResp.body()!!.data ?: emptyList())
                }
            } catch (e: Exception) {
                _summary.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun requestPayout(token: String) {
        _payoutState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.requestPayout(token)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _payoutState.value = UiState.Success(Unit)
                } else {
                    _payoutState.value = UiState.Error("Payout request failed")
                }
            } catch (e: Exception) {
                _payoutState.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }
}

// ─── VehicleViewModel ─────────────────────────────────────────────────────────

class VehicleViewModel(private val repo: PingoproRepository = PingoproRepository()) : ViewModel() {

    private val _vehicle = MutableLiveData<UiState<Vehicle>>()
    val vehicle: LiveData<UiState<Vehicle>> = _vehicle

    fun loadVehicle(token: String) {
        _vehicle.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.getVehicle(token)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _vehicle.value = UiState.Success(resp.body()!!.data!!)
                } else {
                    _vehicle.value = UiState.Error("Failed to load vehicle")
                }
            } catch (e: Exception) {
                _vehicle.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }
}

// ─── ProfileViewModel ─────────────────────────────────────────────────────────

class ProfileViewModel(private val repo: PingoproRepository = PingoproRepository()) : ViewModel() {

    private val _profile = MutableLiveData<UiState<Partner>>()
    val profile: LiveData<UiState<Partner>> = _profile

    private val _logoutState = MutableLiveData<Boolean>()
    val logoutState: LiveData<Boolean> = _logoutState

    fun loadProfile(token: String) {
        _profile.value = UiState.Loading
        viewModelScope.launch {
            try {
                val resp = repo.getProfile(token)
                if (resp.isSuccessful && resp.body()?.success == true) {
                    _profile.value = UiState.Success(resp.body()!!.data!!)
                } else {
                    _profile.value = UiState.Error("Failed to load profile")
                }
            } catch (e: Exception) {
                _profile.value = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun logout() {
        _logoutState.value = true
    }
}
