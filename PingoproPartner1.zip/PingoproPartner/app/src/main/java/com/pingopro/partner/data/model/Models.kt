package com.pingopro.partner.data.model

import com.google.gson.annotations.SerializedName

// ─── Partner / Driver ───────────────────────────────────────────────────────

data class Partner(
    val id: String,
    val name: String,
    val phone: String,
    val email: String,
    val rating: Float,
    val totalTrips: Int,
    val isOnline: Boolean,
    val isVerified: Boolean,
    val joinedDate: String,
    val profileImageUrl: String?,
    val wallet: Wallet,
    val vehicle: Vehicle?
)

data class Wallet(
    val balance: Double,
    val pendingAmount: Double,
    val lastPayout: String
)

// ─── Order ──────────────────────────────────────────────────────────────────

data class Order(
    @SerializedName("id") val id: String,
    @SerializedName("orderId") val orderId: String,
    @SerializedName("status") val status: OrderStatus,
    @SerializedName("pickup") val pickup: Location,
    @SerializedName("dropoff") val dropoff: Location,
    @SerializedName("estimatedFare") val estimatedFare: Double,
    @SerializedName("actualFare") val actualFare: Double?,
    @SerializedName("distanceKm") val distanceKm: Double,
    @SerializedName("estimatedMinutes") val estimatedMinutes: Int,
    @SerializedName("customer") val customer: Customer,
    @SerializedName("vehicleType") val vehicleType: String,
    @SerializedName("scheduledTime") val scheduledTime: String?,
    @SerializedName("createdAt") val createdAt: String,
    @SerializedName("completedAt") val completedAt: String?
)

enum class OrderStatus {
    NEW, ACCEPTED, IN_TRANSIT, DELIVERED, CANCELLED, SCHEDULED
}

data class Location(
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val landmark: String?
)

data class Customer(
    val name: String,
    val phone: String,
    val rating: Float
)

// ─── Vehicle ─────────────────────────────────────────────────────────────────

data class Vehicle(
    val id: String,
    val type: String,
    val make: String,
    val model: String,
    val year: Int,
    val registrationNumber: String,
    val capacityKg: Int,
    val isActive: Boolean,
    val documents: VehicleDocuments
)

data class VehicleDocuments(
    val rc: Document,
    val insurance: Document,
    val permit: Document,
    val fitnesscertificate: Document
)

data class Document(
    val isValid: Boolean,
    val expiryDate: String,
    val documentUrl: String?
)

// ─── Earnings ────────────────────────────────────────────────────────────────

data class EarningsSummary(
    val todayEarnings: Double,
    val weeklyEarnings: Double,
    val monthlyEarnings: Double,
    val totalTripsToday: Int,
    val totalTripsWeek: Int,
    val acceptanceRate: Float,
    val peakHourBonus: Double,
    val weeklyTargetBonus: Double,
    val referralCredit: Double,
    val walletBalance: Double
)

data class DailyEarning(
    val day: String,
    val amount: Double,
    val trips: Int
)

data class TripEarning(
    val orderId: String,
    val pickup: String,
    val dropoff: String,
    val amount: Double,
    val time: String,
    val date: String
)

// ─── API Response Wrapper ────────────────────────────────────────────────────

data class ApiResponse<T>(
    val success: Boolean,
    val data: T?,
    val message: String?,
    val errorCode: Int?
)

// ─── Auth ─────────────────────────────────────────────────────────────────────

data class LoginRequest(
    val phone: String,
    val otp: String
)

data class LoginResponse(
    val token: String,
    val partnerId: String,
    val partner: Partner
)

// ─── Notification ─────────────────────────────────────────────────────────────

data class TripRequest(
    val orderId: String,
    val order: Order,
    val timeoutSeconds: Int = 30
)
