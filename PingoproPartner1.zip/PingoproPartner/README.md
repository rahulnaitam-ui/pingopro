# 🚛 Pingopro Partner App

A full-featured Android partner/driver app for the **Pingopro** logistics platform — built as a clone of the Porter Partner app, fully rebranded and extended with modern Kotlin architecture.

---

## 📱 Screens & Features

| Screen | Features |
|--------|----------|
| **Splash** | Branded launch screen, auto-redirect based on session |
| **Login** | Phone number + OTP authentication |
| **Home** | Online/Offline toggle, live stats, incoming trip request accept/decline, quick actions |
| **Orders** | Active / Upcoming / History tabs, mark delivered, navigate, call customer |
| **Earnings** | Daily/Weekly/Monthly toggle, bar chart, incentives & bonuses, wallet & payout |
| **Vehicle** | Vehicle specs, documents status (RC, Insurance, Permit), upload documents |
| **Profile** | Partner info, ratings, toggle settings, KYC, bank details, refer & earn, logout |

---

## 🏗️ Architecture

```
com.pingopro.partner
├── data/
│   ├── model/          # Data classes (Order, Partner, Vehicle, Earnings...)
│   └── repository/     # PingoproRepository + Retrofit API service
├── ui/
│   ├── SplashActivity
│   ├── MainActivity    # BottomNavigationView + NavHostFragment
│   ├── auth/           # LoginActivity
│   ├── home/           # HomeFragment
│   ├── orders/         # OrdersFragment
│   ├── earnings/       # EarningsFragment
│   ├── vehicle/        # VehicleFragment
│   └── profile/        # ProfileFragment
├── viewmodel/          # HomeViewModel, OrdersViewModel, EarningsViewModel, VehicleViewModel, ProfileViewModel
├── adapter/            # OrdersAdapter, TripEarningsAdapter (ListAdapter + DiffUtil)
└── utils/              # SessionManager, LocationTrackingService
```

**Pattern:** MVVM + Repository + LiveData + Coroutines

---

## 🛠️ Tech Stack

| Library | Purpose |
|---------|---------|
| Kotlin 1.9 | Primary language |
| Navigation Component | Fragment navigation + deep links |
| ViewModel + LiveData | State management |
| Retrofit 2 + OkHttp | REST API calls |
| Kotlin Coroutines | Async/background work |
| MPAndroidChart | Earnings bar chart |
| Glide | Image loading |
| Material Components | UI widgets, BottomNav, Tabs |
| Google Maps SDK | Live map / navigation |
| FusedLocationProvider | GPS location tracking |
| Security Crypto | Encrypted SharedPreferences |

---

## 🚀 Getting Started

### Prerequisites
- Android Studio Hedgehog or later
- Android SDK 34
- Java 17

### Setup Steps

1. **Clone / unzip** the project
2. Open in **Android Studio**
3. In `AndroidManifest.xml`, replace:
   ```xml
   android:value="YOUR_GOOGLE_MAPS_API_KEY"
   ```
   with your actual Google Maps API key from [Google Cloud Console](https://console.cloud.google.com)

4. In `NetworkClient.kt`, update the base URL:
   ```kotlin
   private const val BASE_URL = "https://api.pingopro.com/v1/"
   ```

5. Sync Gradle and **Run** on device or emulator (API 24+)

---

## 🎨 Brand Colors

| Token | Hex | Usage |
|-------|-----|-------|
| `pp_dark_navy` | `#1A1A2E` | Primary background, headers |
| `pp_deep_blue` | `#0F3460` | Gradient end |
| `pp_teal` | `#4ECDC4` | Accent, CTAs, highlights |
| `pp_teal_faint` | `#E0FAF8` | Card backgrounds, chips |
| `pp_green` | `#1A8C4E` | Success states |
| `pp_red` | `#E53935` | Error, logout |

---

## 📂 Key Files

```
app/src/main/
├── AndroidManifest.xml
├── java/com/pingopro/partner/
│   ├── data/model/Models.kt           ← All data classes
│   ├── data/repository/ApiService.kt  ← Retrofit interface
│   ├── data/repository/Repository.kt  ← Repository + NetworkClient
│   ├── viewmodel/ViewModels.kt        ← All 5 ViewModels
│   ├── adapter/Adapters.kt            ← RecyclerView adapters
│   ├── utils/SessionManager.kt        ← Auth session
│   └── utils/LocationTrackingService.kt
└── res/
    ├── layout/                        ← All XML layouts
    ├── navigation/nav_graph.xml       ← Navigation graph
    ├── menu/bottom_nav_menu.xml       ← Bottom nav items
    ├── drawable/                      ← Badges, icons, backgrounds
    └── values/                        ← Colors, strings, themes
```

---

## 🔌 API Integration

Replace the demo stub in `LoginActivity.kt` with real OTP API calls via `PingoproRepository`. All endpoints are defined in `ApiService.kt`:

- `POST /auth/send-otp`
- `POST /auth/verify-otp`
- `GET /partner/profile`
- `PUT /partner/status`
- `GET /orders/active`
- `POST /orders/{id}/accept`
- `POST /orders/{id}/deliver`
- `GET /earnings/summary`
- `POST /earnings/payout`
- `GET /vehicle`

---

## 📦 Dependencies (build.gradle)

Add to your `settings.gradle` if using JitPack (for MPAndroidChart):
```gradle
maven { url 'https://jitpack.io' }
```

---

## 📄 License

© 2026 Pingopro. All rights reserved.
